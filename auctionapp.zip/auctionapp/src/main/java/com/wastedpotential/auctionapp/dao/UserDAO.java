package com.wastedpotential.auctionapp.dao;

import java.util.List;

import com.wastedpotential.auctionapp.model.User;

public interface UserDAO {

	public List<User> getAllUser();

	public User authenticateUser(String email, String password);
	
	public boolean registerUser(User user);
	
}
