package com.wastedpotential.auctionapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wastedpotential.auctionapp.model.User;
import com.wastedpotential.auctionapp.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/users", method=RequestMethod.GET)
	public List<User> getAllUsers(){
		return userService.getAllUsers();
	}
	
	@RequestMapping(value="/users",method=RequestMethod.POST)
	public User authenticateUser(@RequestBody User user) {
		return userService.authenticateUser(user.getEmail(), user.getPassword());
	}
	
	@RequestMapping(value="/user",method=RequestMethod.POST)
	public boolean registerUser(@RequestBody User user) {
		return userService.registerUser(user);
	}
	
}