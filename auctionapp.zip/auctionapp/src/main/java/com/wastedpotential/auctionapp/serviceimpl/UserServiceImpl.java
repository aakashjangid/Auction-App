package com.wastedpotential.auctionapp.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wastedpotential.auctionapp.dao.UserDAO;
import com.wastedpotential.auctionapp.model.User;
import com.wastedpotential.auctionapp.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserDAO userDAO;
	
	public List<User> getAllUsers() {
		return userDAO.getAllUser();
	}

	public User authenticateUser(String email, String password) {
		return userDAO.authenticateUser(email,password);
	}

	public boolean registerUser(User user) {
		return userDAO.registerUser(user);
	}

}