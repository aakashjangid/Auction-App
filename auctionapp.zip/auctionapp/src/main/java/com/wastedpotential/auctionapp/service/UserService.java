package com.wastedpotential.auctionapp.service;

import java.util.List;

import com.wastedpotential.auctionapp.model.User;

public interface UserService {

	public List<User> getAllUsers();

	public User authenticateUser(String email, String password);
	
	public boolean registerUser(User user);
	
}
