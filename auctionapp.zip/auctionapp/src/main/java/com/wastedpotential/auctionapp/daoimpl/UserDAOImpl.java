package com.wastedpotential.auctionapp.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.wastedpotential.auctionapp.dao.UserDAO;
import com.wastedpotential.auctionapp.model.User;
import com.wastedpotential.auctionapp.rowmapper.UserMapper;

@Repository
public class UserDAOImpl implements UserDAO {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<User> getAllUser() {
		List<User> users = null;
		try {
			String sql = "SELECT * FROM users";
			users = jdbcTemplate.query(sql, new UserMapper());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return users;
	}

	public User authenticateUser(String email, String password) {
		User user = null;
		try {
			String sql = "SELECT * FROM users WHERE email=? AND password=?";
			user = jdbcTemplate.queryForObject(sql, new Object[] { email, password }, new UserMapper());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	public boolean registerUser(User user) {
		try {
			String sql = "INSERT INTO users(name,contact,email,password) VALUES(?,?,?,?)";
			jdbcTemplate.update(sql, user.getName(), user.getContact(), user.getEmail(), user.getPassword());
			return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

}
