import { Component, OnInit } from '@angular/core';
import '../../assets/login-animation.js';
import {LoginService} from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private loginService:LoginService) { }

  ngOnInit() {
  }
  email: string;
  password: string;

  ngAfterViewInit() {
    (window as any).initialize();
  }

  login(){
    this.loginService.login(this.email, this.password);
  }

}
